import { useState } from 'react'
import Homepage from './wireframe/Homepage'
import ProductDetail from './wireframe/ProductDetail'
import Cart from './wireframe/Cart'
import Checkout from './wireframe/Checkout'
import OrderTracking from './wireframe/OrderTracking'
import Auth from './wireframe/Auth'

const SCREENS = {
  Homepage,
  'Product Detail': ProductDetail,
  Cart,
  Checkout,
  'Order Tracking': OrderTracking,
  'Login / Register': Auth,
} as const

type ScreenName = keyof typeof SCREENS

export default function App() {
  const [active, setActive] = useState<ScreenName>('Homepage')
  const [open, setOpen] = useState(false)
  const ActiveScreen = SCREENS[active]
  const names = Object.keys(SCREENS) as ScreenName[]

  return (
    <div className="relative">
      {/* Screen switcher — dev preview only, never part of the real site.
          Desktop (md+): always-visible horizontal pill bar, bottom-center.
          Mobile (<md): collapsed round toggle, bottom-right, expands upward
          so it never covers page content. */}

      {/* Desktop bar */}
      <div className="hidden md:flex fixed bottom-4 left-1/2 -translate-x-1/2 z-50 bg-black text-white rounded-full px-2 py-2 flex-wrap justify-center gap-1 shadow-lg max-w-[95vw]">
        {names.map(name => (
          <button
            key={name}
            onClick={() => setActive(name)}
            className={`px-3 py-1.5 rounded-full text-[10px] tracking-wide uppercase font-bold whitespace-nowrap transition-colors ${
              active === name ? 'bg-white text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {name}
          </button>
        ))}
      </div>

      {/* Mobile collapsed toggle */}
      <div className="md:hidden fixed bottom-4 right-4 z-50 flex flex-col items-end gap-2">
        {open && (
          <div className="bg-black text-white rounded-xl p-2 flex flex-col gap-1 shadow-lg w-48">
            {names.map(name => (
              <button
                key={name}
                onClick={() => {
                  setActive(name)
                  setOpen(false)
                }}
                className={`px-3 py-2 rounded-lg text-[11px] tracking-wide uppercase font-bold text-left transition-colors ${
                  active === name ? 'bg-white text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        )}

        <button
          onClick={() => setOpen(o => !o)}
          className="w-11 h-11 rounded-full bg-black text-white flex items-center justify-center shadow-lg text-[16px] font-black"
          aria-label="Toggle screen switcher"
        >
          {open ? '\u00d7' : '\u2630'}
        </button>
      </div>

      <ActiveScreen />
    </div>
  )
}
