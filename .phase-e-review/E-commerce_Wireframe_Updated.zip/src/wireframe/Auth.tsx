import { useState } from 'react'
import { MicroLabel } from './primitives'

export default function Auth() {
  const [mode, setMode] = useState<'login' | 'register'>('login')

  return (
    <div
      className="bg-white text-black min-h-screen flex items-center justify-center px-4 py-10"
      style={{ fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif" }}
    >
      {/* Responsive: full-width card on mobile, fixed max-width from sm up */}
      <div className="w-full sm:max-w-md border-2 border-black p-6 sm:p-8">
        <span
          className="font-black uppercase leading-none block text-center mb-2"
          style={{ fontSize: 28, letterSpacing: '-0.05em' }}
        >
          MARKT
        </span>
        <MicroLabel>
          <span className="block text-center">Nigeria's Market</span>
        </MicroLabel>

        {/* Tab toggle */}
        <div className="flex mt-8 border-2 border-black">
          <button
            onClick={() => setMode('login')}
            className={`flex-1 py-3 text-[11px] tracking-[0.2em] uppercase font-black ${
              mode === 'login' ? 'bg-black text-white' : 'text-neutral-400'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setMode('register')}
            className={`flex-1 py-3 text-[11px] tracking-[0.2em] uppercase font-black border-l-2 border-black ${
              mode === 'register' ? 'bg-black text-white' : 'text-neutral-400'
            }`}
          >
            Register
          </button>
        </div>

        <div className="mt-6 space-y-3">
          {mode === 'register' && (
            <input placeholder="Full Name" className="w-full border-2 border-black/20 p-3 text-[13px] outline-none" />
          )}
          <input placeholder="Email Address" className="w-full border-2 border-black/20 p-3 text-[13px] outline-none" />
          <input
            placeholder="Password"
            type="password"
            className="w-full border-2 border-black/20 p-3 text-[13px] outline-none"
          />
          {mode === 'register' && (
            <input
              placeholder="Phone Number"
              className="w-full border-2 border-black/20 p-3 text-[13px] outline-none"
            />
          )}

          {mode === 'login' && (
            <div className="flex justify-end">
              <span className="text-[11px] font-semibold underline cursor-pointer">Forgot password?</span>
            </div>
          )}

          <button
            style={{ backgroundColor: 'var(--vermilion)' }}
            className="w-full py-4 text-white text-[11px] tracking-[0.2em] uppercase font-black mt-2"
          >
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </div>

        <p className="text-[11px] text-center text-neutral-400 font-medium mt-6">
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <span
            className="underline font-bold text-black cursor-pointer"
            onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
          >
            {mode === 'login' ? 'Register' : 'Sign In'}
          </span>
        </p>
      </div>
    </div>
  )
}
