import { Wire, MicroLabel, Divider, fmt, PageShell } from './primitives'

const CART_ITEMS = [
  { id: 1, name: 'iPhone 15 Pro Max 256GB', price: 1_250_000, qty: 1 },
  { id: 2, name: 'AirPods Pro (3rd Gen)', price: 320_000, qty: 2 },
]

export default function Cart() {
  const subtotal = CART_ITEMS.reduce((s, i) => s + i.price * i.qty, 0)
  const delivery = 3_500
  const total = subtotal + delivery

  return (
    <PageShell title="Your Cart" breadcrumb={`${CART_ITEMS.length} items`}>
      {/* Responsive: summary stacks below items on mobile, sits beside them from lg up */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        {/* ── Cart items ────────────────────────────────────────── */}
        <div className="lg:col-span-8 space-y-4">
          {CART_ITEMS.map(item => (
            <div
              key={item.id}
              className="border-2 border-black flex flex-col sm:flex-row gap-4 p-4"
            >
              <Wire h="h-28 w-full sm:w-28" label="PRODUCT" />
              <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-[14px] font-bold">{item.name}</p>
                  <span className="text-[13px] font-black block mt-1">{fmt(item.price)}</span>
                </div>
                <div className="flex items-center justify-between sm:flex-col sm:items-end gap-2">
                  <div className="flex items-center border-2 border-black w-fit">
                    <button className="px-3 py-2 text-[13px] font-black">−</button>
                    <span className="px-4 py-2 text-[13px] font-bold border-x-2 border-black">
                      {item.qty}
                    </span>
                    <button className="px-3 py-2 text-[13px] font-black">+</button>
                  </div>
                  <button className="text-[10px] uppercase font-bold underline text-neutral-500">
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}

          <div className="border border-black/15 p-4 flex items-center gap-3">
            <input type="text" placeholder="Promo code" className="flex-1 outline-none text-[13px]" />
            <button className="px-5 py-2 border-2 border-black text-[10px] tracking-[0.2em] uppercase font-black">
              Apply
            </button>
          </div>
        </div>

        {/* ── Order summary ─────────────────────────────────────── */}
        <div className="lg:col-span-4">
          <div className="border-2 border-black p-5 sticky top-4">
            <MicroLabel>Order Summary</MicroLabel>
            <div className="mt-4 space-y-3 text-[13px] font-semibold">
              <div className="flex justify-between">
                <span className="text-neutral-500">Subtotal</span>
                <span>{fmt(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Delivery Fee</span>
                <span>{fmt(delivery)}</span>
              </div>
            </div>
            <Divider thick />
            <div className="flex justify-between text-[16px] font-black mt-3">
              <span>Total</span>
              <span>{fmt(total)}</span>
            </div>
            <button
              style={{ backgroundColor: 'var(--vermilion)' }}
              className="w-full py-4 mt-5 text-white text-[11px] tracking-[0.2em] uppercase font-black"
            >
              Proceed to Checkout
            </button>
          </div>
        </div>
      </div>
    </PageShell>
  )
}
