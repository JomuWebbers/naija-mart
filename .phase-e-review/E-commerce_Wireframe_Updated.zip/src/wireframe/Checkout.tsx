import { useState } from 'react'
import { Wire, MicroLabel, Divider, fmt, PageShell } from './primitives'

const STATES = ['Osun', 'Lagos', 'Oyo']
const PAYMENT_METHODS = ['Card (Paystack)', 'Bank Transfer', 'Pay on Delivery']

export default function Checkout() {
  const [state, setState] = useState(STATES[0])
  const [payment, setPayment] = useState(PAYMENT_METHODS[0])

  return (
    <PageShell title="Checkout" breadcrumb="Cart / Delivery / Payment / Review">
      {/* Responsive: form stacks full width on mobile, order summary sits beside it from lg up */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        <div className="lg:col-span-8 space-y-8">

          {/* ── Delivery address ──────────────────────────────────── */}
          <section>
            <MicroLabel>1. Delivery Address</MicroLabel>
            <div className="border-2 border-black p-4 mt-3 space-y-3">
              <input placeholder="Full Name" className="w-full border border-black/20 p-3 text-[13px] outline-none" />
              <input placeholder="Phone Number" className="w-full border border-black/20 p-3 text-[13px] outline-none" />
              <input placeholder="Street Address" className="w-full border border-black/20 p-3 text-[13px] outline-none" />

              {/* Responsive: two columns from sm up, stacked on mobile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input placeholder="City" className="w-full border border-black/20 p-3 text-[13px] outline-none" />
                <select
                  value={state}
                  onChange={e => setState(e.target.value)}
                  className="w-full border border-black/20 p-3 text-[13px] outline-none"
                >
                  {STATES.map(s => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              <MicroLabel>Delivery tracking is available in Osun, Lagos, and Oyo states</MicroLabel>
            </div>
          </section>

          {/* ── Payment method ────────────────────────────────────── */}
          <section>
            <MicroLabel>2. Payment Method</MicroLabel>
            <div className="mt-3 space-y-2">
              {PAYMENT_METHODS.map(m => (
                <label
                  key={m}
                  className={`flex items-center gap-3 border-2 p-4 cursor-pointer ${
                    payment === m ? 'border-black' : 'border-black/15'
                  }`}
                >
                  <input
                    type="radio"
                    checked={payment === m}
                    onChange={() => setPayment(m)}
                    className="accent-black"
                  />
                  <span className="text-[13px] font-semibold">{m}</span>
                </label>
              ))}
            </div>
          </section>

          {/* ── Order items review ────────────────────────────────── */}
          <section>
            <MicroLabel>3. Review Items</MicroLabel>
            <div className="space-y-3 mt-3">
              {[1, 2].map(i => (
                <div key={i} className="flex items-center gap-4 border border-black/15 p-3">
                  <Wire h="h-16 w-16" />
                  <div className="flex-1">
                    <MicroLabel>ITEM {i}</MicroLabel>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* ── Order total + place order ──────────────────────────── */}
        <div className="lg:col-span-4">
          <div className="border-2 border-black p-5 sticky top-4">
            <MicroLabel>Order Total</MicroLabel>
            <div className="mt-4 space-y-3 text-[13px] font-semibold">
              <div className="flex justify-between">
                <span className="text-neutral-500">Subtotal</span>
                <span>{fmt(1_890_000)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Delivery Fee</span>
                <span>{fmt(3_500)}</span>
              </div>
            </div>
            <Divider thick />
            <div className="flex justify-between text-[16px] font-black mt-3">
              <span>Total</span>
              <span>{fmt(1_893_500)}</span>
            </div>
            <button
              style={{ backgroundColor: 'var(--vermilion)' }}
              className="w-full py-4 mt-5 text-white text-[11px] tracking-[0.2em] uppercase font-black"
            >
              Place Order
            </button>
          </div>
        </div>
      </div>
    </PageShell>
  )
}
