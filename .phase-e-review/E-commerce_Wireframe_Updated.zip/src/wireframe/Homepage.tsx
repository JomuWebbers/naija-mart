import { useState } from 'react'
import { Wire, MicroLabel, fmt, pct } from './primitives'

// ─── Data ────────────────────────────────────────────────────────────────────

const NAV_CATEGORIES = [
  'All', 'Electronics', 'Fashion', 'Home & Kitchen',
  'Computing', 'Phones & Tablets', 'Baby Products', 'Gaming', 'Sports & Fitness',
]

const PRODUCTS = [
  { id: 1,  name: 'iPhone 15 Pro Max 256GB',          price: 1_250_000, original: 1_560_000, cat: 'Electronics',    tag: 'PHONES & TABLETS'  },
  { id: 2,  name: 'Samsung 55" QLED 4K Smart TV',      price: 448_000,   original: 680_000,   cat: 'Electronics',    tag: 'ELECTRONICS'       },
  { id: 3,  name: 'HP EliteBook 840 G9 Laptop',        price: 895_000,   original: 1_100_000, cat: 'Computing',      tag: 'COMPUTING'         },
  { id: 4,  name: 'Nike Air Max 270 React',             price: 64_000,    original: 85_000,    cat: 'Sports & Fitness', tag: 'SPORTS & FITNESS' },
  { id: 5,  name: 'Ankara Midi Wrap Dress',             price: 19_500,    original: 26_000,    cat: 'Fashion',        tag: 'FASHION'           },
  { id: 6,  name: 'Dyson V15 Detect Cordless Vacuum',  price: 378_000,   original: 420_000,   cat: 'Home & Kitchen', tag: 'HOME & KITCHEN'    },
  { id: 7,  name: 'PlayStation 5 Disc Edition',         price: 550_000,   original: 720_000,   cat: 'Gaming',         tag: 'GAMING'            },
  { id: 8,  name: 'Instant Pot Duo 7-in-1 6Qt',        price: 92_000,    original: 118_000,   cat: 'Home & Kitchen', tag: 'HOME & KITCHEN'    },
]

const FLASH_DEALS = [
  { id: 9,  name: 'AirPods Pro (3rd Gen)',              price: 320_000,   original: 420_000,   tag: 'AUDIO'           },
  { id: 10, name: 'Canon EOS R50 Mirrorless Camera',    price: 680_000,   original: 890_000,   tag: 'CAMERAS'         },
  { id: 11, name: 'Ninja AF101 Air Fryer 3.8L',         price: 57_000,    original: 82_000,    tag: 'HOME & KITCHEN'  },
  { id: 12, name: 'JBL Charge 5 Bluetooth Speaker',     price: 98_000,    original: 135_000,   tag: 'AUDIO'           },
]

const NEW_ARRIVALS = [
  { id: 13, name: 'Samsung Galaxy S24 Ultra',           price: 1_150_000, tag: 'PHONES'        },
  { id: 14, name: 'Linen Blend Tailored Suit — Slate',  price: 78_000,    tag: 'FASHION'       },
  { id: 15, name: 'Bosch Serie 6 Dishwasher',           price: 520_000,   tag: 'HOME'          },
  { id: 16, name: 'DJI Mini 4 Pro Drone',               price: 780_000,   tag: 'ELECTRONICS'   },
]

const SHOWCASE_CATS = [
  { label: 'ELECTRONICS',    count: '4,200+' },
  { label: 'FASHION',        count: '12,800+' },
  { label: 'HOME & KITCHEN', count: '6,400+' },
  { label: 'COMPUTING',      count: '2,100+' },
  { label: 'GAMING',         count: '1,800+' },
  { label: 'SPORTS',         count: '3,600+' },
]

const FOOTER_COLS = [
  { heading: 'Shop',    links: ['All Products', 'Flash Deals', 'New Arrivals', 'Best Sellers', 'Brand Store']  },
  { heading: 'Account', links: ['Sign In', 'Register', 'My Orders', 'Wishlist', 'Returns & Refunds']          },
  { heading: 'Sell',    links: ['Start Selling', 'Seller Hub', 'Seller Protection', 'Seller Policies', 'Advertise'] },
  { heading: 'Help',    links: ['Contact Support', 'FAQs', 'Delivery Info', 'Payment Options', 'Track Order'] },
]

// ─── Product Cards ────────────────────────────────────────────────────────────

function ProductCard({ name, price, original, tag }: {
  name: string; price: number; original: number; tag: string
}) {
  return (
    <div className="border-t-2 border-black group cursor-pointer">
      <Wire h="h-32 sm:h-44" label="PRODUCT IMAGE" />
      <div className="p-3 space-y-1.5">
        <MicroLabel>{tag}</MicroLabel>
        <p className="text-[13px] font-semibold leading-snug line-clamp-2 mt-1">{name}</p>
        <div className="flex items-baseline gap-2 pt-1 flex-wrap">
          <span className="text-[15px] font-black">{fmt(price)}</span>
          <span className="text-[11px] text-neutral-400 line-through">{fmt(original)}</span>
          <span className="text-[9px] font-black bg-black text-white px-1.5 py-0.5">
            -{pct(price, original)}%
          </span>
        </div>
      </div>
    </div>
  )
}

function DealCard({ name, price, original, tag }: {
  name: string; price: number; original: number; tag: string
}) {
  return (
    <div className="bg-white text-black border-t-2 border-white/40 group cursor-pointer">
      <Wire h="h-28 sm:h-40" label="PRODUCT" />
      <div className="p-3 space-y-1">
        <MicroLabel>{tag}</MicroLabel>
        <p className="text-[13px] font-semibold leading-snug line-clamp-2 mt-1">{name}</p>
        <div className="flex items-baseline gap-2 pt-1 flex-wrap">
          <span className="text-[14px] font-black">{fmt(price)}</span>
          <span className="text-[9px] font-black bg-black text-white px-1.5 py-0.5">
            -{pct(price, original)}%
          </span>
        </div>
      </div>
    </div>
  )
}

function ArrivalCard({ name, price, tag }: { name: string; price: number; tag: string }) {
  return (
    <div className="border-t-2 border-black cursor-pointer">
      <Wire h="h-32 sm:h-44" label="NEW" />
      <div className="p-3 space-y-1.5">
        <MicroLabel>{tag}</MicroLabel>
        <p className="text-[13px] font-semibold leading-snug mt-1">{name}</p>
        <span className="text-[15px] font-black block pt-1">{fmt(price)}</span>
      </div>
    </div>
  )
}

// ─── Homepage ──────────────────────────────────────────────────────────────

export default function Homepage() {
  const [activeNav, setActiveNav] = useState('All')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const filtered = activeNav === 'All'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.cat === activeNav)

  return (
    <div
      className="bg-white text-black min-h-screen overflow-x-hidden"
      style={{ fontFamily: "'Barlow', 'Helvetica Neue', Arial, sans-serif" }}
    >

      {/* ── Announcement Bar — secondary links hidden on mobile ─────────── */}
      <div className="bg-black text-white py-2 px-4 md:px-8">
        <div className="max-w-screen-2xl mx-auto flex items-center justify-between">
          <span className="text-[9px] md:text-[10px] tracking-[0.15em] md:tracking-[0.2em] uppercase font-semibold">
            Free delivery on orders above ₦50,000
          </span>
          <div className="hidden md:flex items-center gap-6">
            {['Sell on Markt', 'Track Order', 'Help Center'].map(s => (
              <button
                key={s}
                className="text-[10px] tracking-[0.18em] uppercase font-semibold text-neutral-400 hover:text-white transition-colors"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Header — logo + hamburger on mobile, full row from lg up ────── */}
      <header className="border-b-2 border-black px-4 md:px-8 py-4 md:py-5">
        <div className="max-w-screen-2xl mx-auto flex items-center justify-between lg:justify-start gap-4 lg:gap-10">

          {/* Logo */}
          <div className="shrink-0 flex flex-col">
            <span
              className="font-black uppercase leading-none"
              style={{ fontSize: 24, letterSpacing: '-0.05em' }}
            >
              MARKT
            </span>
            <MicroLabel>Nigeria's Market</MicroLabel>
          </div>

          {/* Delivery location — hidden below lg, same as original */}
          <div className="shrink-0 hidden lg:flex flex-col cursor-pointer">
            <MicroLabel>Deliver To</MicroLabel>
            <span className="text-[13px] font-bold mt-0.5">Lagos, NG ▾</span>
          </div>

          {/* Search — full row on its own below header on mobile, inline from lg up */}
          <div className="hidden lg:flex flex-1 border-2 border-black">
            <select className="px-3 py-2.5 text-[11px] tracking-widest uppercase font-semibold bg-neutral-100 border-r-2 border-black outline-none cursor-pointer shrink-0">
              <option>All</option>
              <option>Electronics</option>
              <option>Fashion</option>
              <option>Computing</option>
            </select>
            <input
              type="text"
              placeholder="Search products, brands and categories…"
              className="flex-1 px-4 py-2.5 text-sm outline-none bg-transparent"
            />
            <button className="px-6 py-2.5 bg-black text-white text-[10px] tracking-[0.2em] uppercase font-bold shrink-0">
              Search
            </button>
          </div>

          {/* Account & Cart — condensed to icons-only on mobile via labels hidden */}
          <div className="hidden lg:flex items-center gap-8 shrink-0">
            <button className="flex flex-col items-start">
              <MicroLabel>Account</MicroLabel>
              <span className="text-[13px] font-bold mt-0.5">Sign In ▾</span>
            </button>
            <button className="flex flex-col items-start">
              <MicroLabel>Returns</MicroLabel>
              <span className="text-[13px] font-bold mt-0.5">& Orders</span>
            </button>
            <button className="flex flex-col items-start relative">
              <MicroLabel>Shopping</MicroLabel>
              <span className="text-[13px] font-bold mt-0.5">Cart (3)</span>
            </button>
          </div>

          {/* Mobile: cart icon + hamburger */}
          <div className="flex lg:hidden items-center gap-4 shrink-0">
            <span className="text-[12px] font-bold">Cart (3)</span>
            <button
              onClick={() => setMobileMenuOpen(o => !o)}
              className="w-8 h-8 border-2 border-black flex flex-col items-center justify-center gap-1"
              aria-label="Menu"
            >
              <span className="w-4 h-0.5 bg-black" />
              <span className="w-4 h-0.5 bg-black" />
              <span className="w-4 h-0.5 bg-black" />
            </button>
          </div>
        </div>

        {/* Mobile search row — always visible under the logo row on small screens */}
        <div className="lg:hidden max-w-screen-2xl mx-auto mt-3 flex border-2 border-black">
          <input
            type="text"
            placeholder="Search products…"
            className="flex-1 px-3 py-2 text-sm outline-none bg-transparent"
          />
          <button className="px-4 py-2 bg-black text-white text-[10px] tracking-[0.2em] uppercase font-bold shrink-0">
            Go
          </button>
        </div>

        {/* Mobile dropdown menu — account, deliver-to, replicated from desktop */}
        {mobileMenuOpen && (
          <div className="lg:hidden max-w-screen-2xl mx-auto mt-3 border-2 border-black divide-y-2 divide-black">
            <div className="p-3 flex justify-between items-center">
              <MicroLabel>Deliver To</MicroLabel>
              <span className="text-[13px] font-bold">Lagos, NG ▾</span>
            </div>
            <div className="p-3 flex justify-between items-center">
              <MicroLabel>Account</MicroLabel>
              <span className="text-[13px] font-bold">Sign In ▾</span>
            </div>
            <div className="p-3 flex justify-between items-center">
              <MicroLabel>Returns & Orders</MicroLabel>
            </div>
            {['Sell on Markt', 'Track Order', 'Help Center'].map(s => (
              <div key={s} className="p-3">
                <span className="text-[11px] tracking-[0.15em] uppercase font-semibold">{s}</span>
              </div>
            ))}
          </div>
        )}
      </header>

      {/* ── Category Nav — horizontal scroll works at every width already ── */}
      <nav className="border-b border-black/15 bg-neutral-50 px-4 md:px-8">
        <div className="max-w-screen-2xl mx-auto flex items-center overflow-x-auto gap-0">
          {NAV_CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveNav(cat)}
              className={`shrink-0 px-4 py-3 text-[10px] tracking-[0.18em] uppercase font-semibold border-b-2 transition-none whitespace-nowrap ${
                activeNav === cat
                  ? 'border-black text-black'
                  : 'border-transparent text-neutral-500 hover:text-black'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </nav>

      {/* ── Hero — stacked on mobile, side-by-side from md up ────────────── */}
      <section className="border-b-2 border-black px-4 md:px-8 py-10 md:py-16">
        <div className="max-w-screen-2xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">

          <div className="md:col-span-7 xl:col-span-6 flex flex-col items-start">
            <MicroLabel>Nigeria's Largest Online Marketplace</MicroLabel>

            <h1
              className="font-black uppercase leading-none mt-4 mb-6"
              style={{ fontSize: 'clamp(36px, 7.5vw, 116px)', letterSpacing: '-0.04em' }}
            >
              MILLIONS<br />OF DEALS.<br />ONE PLACE.
            </h1>

            <p className="text-[14px] md:text-[15px] text-neutral-600 font-medium max-w-sm mb-8 leading-relaxed">
              Electronics, fashion, home essentials and more —
              shipped fast to your door across all 36 states.
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <button
                style={{ backgroundColor: 'var(--vermilion)' }}
                className="px-10 py-4 text-white text-[10px] tracking-[0.25em] uppercase font-black"
              >
                Shop Now
              </button>
              <button className="px-10 py-4 text-black text-[10px] tracking-[0.25em] uppercase font-black border-2 border-black">
                View Deals
              </button>
            </div>

            {/* Trust badges — wraps into 2 columns on very small screens */}
            <div className="flex flex-wrap items-center gap-6 md:gap-8 mt-10 pt-8 border-t border-black/15 w-full">
              {['Free Returns', '100% Authentic', 'Secure Payments', 'Fast Delivery'].map(t => (
                <div key={t} className="flex flex-col gap-0.5">
                  <div className="w-4 h-4 bg-black" />
                  <MicroLabel>{t}</MicroLabel>
                </div>
              ))}
            </div>
          </div>

          <div className="md:col-span-5 xl:col-span-6 grid grid-cols-2 gap-3">
            <Wire h="h-48 sm:h-72" label="HERO IMAGE" />
            <div className="flex flex-col gap-3">
              <Wire h="h-[92px] sm:h-36" label="PROMO TILE" />
              <Wire h="h-[92px] sm:h-36" label="PROMO TILE" />
            </div>
          </div>
        </div>
      </section>

      {/* ── Category Showcase — 2 cols mobile, 3 sm, 6 from md up ────────── */}
      <section className="px-4 md:px-8 py-10 md:py-12 border-b border-black/15">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex items-baseline gap-4 mb-6">
            <MicroLabel>Browse By</MicroLabel>
            <h2
              className="font-black uppercase"
              style={{ fontSize: 18, letterSpacing: '-0.03em' }}
            >
              Category
            </h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 border-l-2 border-t-2 border-black">
            {SHOWCASE_CATS.map(sc => (
              <div key={sc.label} className="border-r-2 border-b-2 border-black p-4 cursor-pointer hover:bg-neutral-50">
                <Wire h="h-16 sm:h-20" />
                <div className="mt-3">
                  <MicroLabel>{sc.label}</MicroLabel>
                  <p className="text-[10px] tracking-widest uppercase text-neutral-300 font-medium mt-0.5">
                    {sc.count} items
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Flash Sale — 2 cols mobile, 4 from sm up ─────────────────────── */}
      <section className="border-t-2 border-b-2 border-black bg-black text-white px-4 md:px-8 py-10 md:py-12">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-baseline gap-6 md:gap-8 flex-wrap">
              <h2
                className="font-black uppercase leading-none"
                style={{ fontSize: 20, letterSpacing: '-0.03em' }}
              >
                Flash Sale
              </h2>
              <div className="flex items-center gap-2">
                <MicroLabel>Ends In</MicroLabel>
                <div className="flex items-center gap-1 ml-2">
                  {['02', '14', '38'].map((t, i) => (
                    <span key={i} className="flex items-center gap-1">
                      <span className="bg-white text-black text-[13px] font-black px-2 py-0.5 font-mono leading-tight">
                        {t}
                      </span>
                      {i < 2 && <span className="text-white/50 font-black text-sm">:</span>}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <button className="text-[10px] tracking-[0.2em] uppercase font-black border border-white px-6 py-3 hover:bg-white hover:text-black transition-colors self-start sm:self-auto">
              All Deals
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
            {FLASH_DEALS.map(d => (
              <DealCard key={d.id} {...d} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Best Sellers — 2 cols mobile, 4 from sm up ───────────────────── */}
      <section className="px-4 md:px-8 py-10 md:py-12 border-b border-black/15">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex items-baseline justify-between mb-6">
            <div>
              <MicroLabel>
                {activeNav === 'All' ? 'All Categories' : activeNav}
              </MicroLabel>
              <h2
                className="font-black uppercase mt-1"
                style={{ fontSize: 18, letterSpacing: '-0.03em' }}
              >
                Best Sellers
              </h2>
            </div>
            <button className="text-[10px] tracking-[0.2em] uppercase font-black border-b-2 border-black pb-0.5">
              View All
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
            {(filtered.length > 0 ? filtered : PRODUCTS).map(p => (
              <ProductCard key={p.id} name={p.name} price={p.price} original={p.original} tag={p.tag} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Promo Banner — stacked on mobile, side-by-side from md up ────── */}
      <section className="border-t-2 border-b-2 border-black bg-neutral-50 px-4 md:px-8 py-10 md:py-16">
        <div className="max-w-screen-2xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7">
            <MicroLabel>Limited Time Offer · This Week Only</MicroLabel>
            <p
              className="font-black uppercase leading-none mt-3"
              style={{ fontSize: 'clamp(28px, 4vw, 60px)', letterSpacing: '-0.04em' }}
            >
              UP TO 70% OFF<br />SELECTED ITEMS
            </p>
            <p className="text-[14px] text-neutral-600 font-medium mt-4 leading-relaxed">
              Over 2,400 products marked down this week.
              New discounts added every 24 hours.
            </p>
          </div>
          <div className="md:col-span-5 flex flex-col gap-4">
            <div className="p-5 border-2 border-black bg-white">
              <MicroLabel>Use Promo Code</MicroLabel>
              <p
                className="font-black uppercase tracking-tight mt-2"
                style={{ fontSize: 32, letterSpacing: '-0.04em' }}
              >
                MARKT70
              </p>
            </div>
            <button className="w-full py-4 bg-black text-white text-[10px] tracking-[0.25em] uppercase font-black">
              Claim Discount
            </button>
          </div>
        </div>
      </section>

      {/* ── New Arrivals — 2 cols mobile, 4 from sm up ───────────────────── */}
      <section className="px-4 md:px-8 py-10 md:py-12 border-b border-black/15">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex items-baseline justify-between mb-6">
            <h2
              className="font-black uppercase"
              style={{ fontSize: 18, letterSpacing: '-0.03em' }}
            >
              New Arrivals
            </h2>
            <button className="text-[10px] tracking-[0.2em] uppercase font-black border-b-2 border-black pb-0.5">
              View All New
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
            {NEW_ARRIVALS.map(p => (
              <ArrivalCard key={p.id} {...p} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Brand Strip — wraps into 4 cols mobile, single row from md up ── */}
      <section className="border-t-2 border-b-2 border-black px-4 md:px-8 py-8 bg-neutral-50">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex items-center gap-8 mb-5">
            <MicroLabel>Official Brand Stores</MicroLabel>
          </div>
          <div className="flex flex-wrap items-center gap-0 border-l-2 border-t-2 border-black">
            {['SAMSUNG', 'APPLE', 'HP', 'SONY', 'NIKE', 'DYSON', 'CANON', 'LG'].map(b => (
              <div
                key={b}
                className="w-1/2 sm:w-1/4 md:flex-1 border-r-2 border-b-2 border-black h-16 flex items-center justify-center cursor-pointer hover:bg-white transition-colors"
              >
                <span className="text-[10px] md:text-[11px] tracking-[0.15em] md:tracking-[0.2em] uppercase font-black text-neutral-400">
                  {b}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer — stacked/columns adapt across breakpoints ────────────── */}
      <footer className="bg-black text-white px-4 md:px-8 pt-10 md:pt-14 pb-8">
        <div className="max-w-screen-2xl mx-auto">

          {/* Top grid — 2 cols mobile, 3 sm, 5 from md up */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-8 md:gap-12 mb-12 pb-12 border-b border-white/10">
            <div className="col-span-2 sm:col-span-3 md:col-span-1">
              <span
                className="font-black uppercase leading-none block mb-3"
                style={{ fontSize: 24, letterSpacing: '-0.05em' }}
              >
                MARKT
              </span>
              <p className="text-[12px] text-neutral-400 leading-relaxed font-medium max-w-sm">
                Nigeria's largest online marketplace. Fast delivery and buyer protection guaranteed across all 36 states.
              </p>
              <div className="flex items-center gap-2 mt-6">
                {['APP STORE', 'GOOGLE PLAY'].map(s => (
                  <div key={s} className="border border-white/20 px-3 py-2">
                    <span className="text-[9px] tracking-[0.18em] uppercase font-semibold">{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {FOOTER_COLS.map(col => (
              <div key={col.heading}>
                <MicroLabel>{col.heading}</MicroLabel>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map(link => (
                    <li key={link}>
                      <a href="#" className="text-[12px] text-neutral-400 hover:text-white font-medium transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Payment methods — wraps on mobile */}
          <div className="flex flex-wrap items-center gap-4 mb-8 pb-8 border-b border-white/10">
            <MicroLabel>Accepted Payments</MicroLabel>
            <div className="flex flex-wrap items-center gap-2">
              {['VISA', 'MASTERCARD', 'VERVE', 'PAYSTACK', 'OPAY', 'USSD'].map(m => (
                <div key={m} className="border border-white/20 px-2.5 py-1">
                  <span className="text-[9px] tracking-[0.15em] uppercase font-black text-neutral-300">{m}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom — stacked on mobile */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <MicroLabel>© 2026 Markt Technologies Ltd. All Rights Reserved.</MicroLabel>
            <div className="flex flex-wrap justify-center items-center gap-4 sm:gap-6">
              {['Privacy Policy', 'Terms of Use', 'Cookie Policy', 'Sitemap'].map(link => (
                <a
                  key={link}
                  href="#"
                  className="text-[9px] tracking-[0.18em] uppercase font-semibold text-neutral-500 hover:text-white transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
