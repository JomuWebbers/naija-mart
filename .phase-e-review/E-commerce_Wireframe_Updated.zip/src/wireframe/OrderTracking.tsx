import { Wire, MicroLabel, Divider, PageShell } from './primitives'

const STATUS_STEPS = ['Placed', 'Confirmed', 'Out for Delivery', 'Delivered']
const CURRENT_STEP = 2 // "Out for Delivery"

export default function OrderTracking() {
  return (
    <PageShell title="Track Order" breadcrumb="Order #NM-20260906-0031">
      {/* Responsive: map + details stack on mobile, side-by-side from lg up */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        {/* ── Live map ──────────────────────────────────────────── */}
        <div className="lg:col-span-7">
          <Wire h="h-72 md:h-[420px]" label="LIVE MAP — DELIVERY PARTNER LOCATION (LEAFLET)" />
          <div className="flex flex-wrap items-center justify-between gap-2 mt-3 border border-black/15 p-3">
            <MicroLabel>Delivery Partner</MicroLabel>
            <span className="text-[13px] font-bold">Chinedu O. — Bike · ★ 4.8</span>
            <button className="text-[10px] uppercase font-bold underline">Call</button>
          </div>
        </div>

        {/* ── Status + OTP ──────────────────────────────────────── */}
        <div className="lg:col-span-5 space-y-6">

          {/* Status timeline — horizontal scroll on mobile, vertical list from md up could also work,
              kept horizontal + wrapping here for simplicity across breakpoints */}
          <div>
            <MicroLabel>Order Status</MicroLabel>
            <div className="flex flex-wrap gap-2 mt-3">
              {STATUS_STEPS.map((step, i) => (
                <div
                  key={step}
                  className={`px-3 py-2 border-2 text-[10px] tracking-[0.1em] uppercase font-bold ${
                    i <= CURRENT_STEP ? 'border-black bg-black text-white' : 'border-black/20 text-neutral-400'
                  }`}
                >
                  {step}
                </div>
              ))}
            </div>
          </div>

          <Divider />

          {/* Delivery OTP — used to confirm handoff at drop-off */}
          <div className="border-2 border-black p-4">
            <MicroLabel>Delivery Confirmation Code</MicroLabel>
            <p className="text-[11px] text-neutral-500 font-medium mt-2 leading-relaxed">
              Share this code with your delivery partner only when your order arrives, to confirm receipt.
            </p>
            <div className="flex gap-2 mt-4">
              {['4', '8', '2', '1'].map((d, i) => (
                <div
                  key={i}
                  className="w-12 h-14 border-2 border-black flex items-center justify-center text-[20px] font-black"
                >
                  {d}
                </div>
              ))}
            </div>
          </div>

          <Divider />

          {/* Delivery address recap */}
          <div>
            <MicroLabel>Delivering To</MicroLabel>
            <Wire h="h-20" label="ADDRESS SUMMARY — OSUN / LAGOS / OYO" />
          </div>

          <div>
            <MicroLabel>Estimated Arrival</MicroLabel>
            <p className="text-[16px] font-black mt-1">Today, 3:45 PM</p>
          </div>
        </div>
      </div>
    </PageShell>
  )
}
